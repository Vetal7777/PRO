
const textE = document.getElementById('text');

const btn = document.querySelector('#btn');

function onClick(){
    textE.classList.toggle('blue');
}

btn.addEventListener('click',onClick);
//при событии клик вызывается наша функция


// Keyboard events
// 'keydown'// first
// 'keypress' // second
// 'keyup'   // third
//
// // Mouse events
// 'mousedown' // first
// 'mouseup' // second
// 'click'  // third