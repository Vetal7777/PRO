console.log('Start');
const interval = setInterval(() => console.log('Hello'), 1000);
setTimeout(() => clearInterval(interval), 7000);
console.log('Finish');