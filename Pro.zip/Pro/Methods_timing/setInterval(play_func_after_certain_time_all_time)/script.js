console.log('Start');
const interval = setInterval(() => console.log('Hello'), 1000);
console.log('Finish');