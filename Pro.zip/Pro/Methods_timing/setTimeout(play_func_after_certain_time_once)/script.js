console.log('Start');
setTimeout(() => console.log('TIMEOUT'), 1000);
console.log('Finish');