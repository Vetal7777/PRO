const bodyE = document.querySelector('.test');

class Test{
    constructor(div) {
        this.container = div;
        this.container.addEventListener('click',this.sayHi);
    }
    sayHi=()=>{
        console.log(this.container);
    }
}

const test = new Test(bodyE);
