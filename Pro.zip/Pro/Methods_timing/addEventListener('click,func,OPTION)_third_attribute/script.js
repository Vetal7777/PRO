document
    .querySelector('.out.one')
    .addEventListener('click',(e) => {
        console.log('OUT 1');
    });
document
    .querySelector('.second.one')
    .addEventListener('click',(e) => {
        console.log('SECOND 1');
    });
document
    .querySelector('.inner.one')
    .addEventListener('click',(e) => {
        console.log('INNER 1');
    });

//Если ты кликнул по INNER  то обработчики будут идти
//в таком порядке
// -------> INNER,SECOND,OUT
//то есть с внутреннего на внешний

document
    .querySelector('.out.two')
    .addEventListener('click',(e) => {
        console.log('OUT 2');
    },true);
document
    .querySelector('.second.two')
    .addEventListener('click',(e) => {
        console.log('SECOND 2');
    },true);
document
    .querySelector('.inner.two')
    .addEventListener('click',(e) => {
        console.log('INNER 2');
    },true);
//Если мы хотим чтобы обработчик шел в другом порядке
//Нам необходимо воспользоваться третьим атрибутом addEventListener
