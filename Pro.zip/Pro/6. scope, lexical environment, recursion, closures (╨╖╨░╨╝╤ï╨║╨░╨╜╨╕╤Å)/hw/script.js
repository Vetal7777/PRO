function counter(){
    let i = 0;
    return () => {
        i++;
        return i;
    }
}

const result = counter();

result();
result();
result();
result();
result();
result();
result();
result();
result();
result();
result();
result();

console.log(result());