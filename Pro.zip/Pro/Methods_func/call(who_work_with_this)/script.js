function User(firstName,age){
    this.name = firstName;
    this.age = age;
    this.sayHi = function (){
        console.log('hello from',this.name);
    };
}

const vasya = new User('Vasya',333);
const irina = new User('Irina',222);

function getAge(){
    console.log('Age',this.age);
}

getAge.call(vasya);