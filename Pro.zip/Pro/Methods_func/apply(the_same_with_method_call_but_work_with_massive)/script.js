function showFullName(firstName,surname,age){
    console.log(`My name : ${firstName} ${surname}, ${age} years old`);
}

const user = {
    age: 26,
}


showFullName.apply(user, ['Vasia', 'Ivanov',user.age]);