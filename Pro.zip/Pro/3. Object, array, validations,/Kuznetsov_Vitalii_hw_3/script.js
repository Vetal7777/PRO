const exampleOperation = ['+','-','/','*'];

function askOperation(){
    //Создаем функцию которая спрашивает операнд
    do {
        a = prompt('Enter the operation','/');
        if(!(exampleOperation.includes(a))){
            alert('You have, a mistake. Try again.');
        }
    }while (!(exampleOperation.includes(a)))
    return a;
//    Добавляет в конце наш операнд в масив
}


function askQualityOperands(a){
    //Создаем функцию которая спрашивает количество операндов
    do {
        a = +prompt('Enter the quality operands',2);
        //Наш вопрос
        if(!(a > 1) || !(a < 5)){
            alert('You have, a mistake. Try again.');
        }
        //    Так же будет всплывать окно с Ошибкой если пользователь ввел не корректное значение

    }while(!(a > 1) || !(a < 5))
    return a;
    //    В конце функция возвращает значение ввода
}


function askOperands(a){
    //Создаем функцию которая спрашивает операнд
    do {
        a = +prompt('Enter the operand',1);
        //Наш вопрос
        if(!Number(a)){
            alert('You have, a mistake. Try again.');
        }
        //    Так же будет всплывать окно с Ошибкой если пользователь ввел не корректное значение
    }while (!Number(a))
    operands.splice(+quality, 0, a);
//    Добавляет в конце наш операнд в масив
}


function askOperandsRepeatedly(b){
    do {
        askOperands();
        b--;
    }while (b > 0)
}
//Предедущий шаг будет выполняться пока пользователь не напишет подходящее значение, для того количество операндов которое нужно.

const operands = [];
//Создаем массив с операндами

const operation = askOperation();
//Присваиваем переменной знанчение операции, и вызываем функцию

const quality = askQualityOperands();
//Присваиваем переменной значение количества операндов, и вызываем функции

askOperandsRepeatedly(quality);
//Вызываем операцию определения операндов то количество раз какую указал пользователь ранее

let sumOperands = operands.reduce((sum, current) => sum + current);
let differenceOperands = operands.reduce((sum, current) => sum - current);
let multiplyOperands = operands.reduce((sum, current) => sum * current);
let divideOperands = operands.reduce((sum, current) => sum / current);
//Присваиваем переменным резултаты всех возможных результатов

function calculateResult(a){
    switch (a){
        case '+':
            return sumOperands;
            break;
        case '-':
            return differenceOperands;
            break;
        case '*':
            return multiplyOperands;
            break;
        case '/':
            return divideOperands;
            break;
    }
}
//Создаем функцию определения, какой результат показываем пользывателю

const result = calculateResult(operation);

function showResult(a){
    let calculation = '';
    a = a - 2;
    do{
        calculation = `${operands[a]} ${operation} `+ calculation;
        a--;
    }while (a > -1)
    return ( calculation + `${operands[operands.length-1]} = ${result}`);
}

const equation = showResult(quality)

alert(equation);
