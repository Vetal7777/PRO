function User(name) {
    if (!new.target) { // в случае, если вы вызвали без оператора new
        return new User(name); // ...добавим оператор new за вас
    }

    this.name = name;
}

let vasya = User("Вася"); // переадресовывает вызовы на new User
alert(vasya.name); // Вася