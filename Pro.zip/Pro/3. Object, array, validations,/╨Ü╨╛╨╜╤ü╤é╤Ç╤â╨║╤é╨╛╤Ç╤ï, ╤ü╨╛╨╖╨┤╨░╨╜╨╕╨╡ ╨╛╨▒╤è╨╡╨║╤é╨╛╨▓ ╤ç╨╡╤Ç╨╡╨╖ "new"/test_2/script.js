function SmallUser() {

    this.name = "Вася";

    return; // <-- возвращает this
}

console.log( new SmallUser() );