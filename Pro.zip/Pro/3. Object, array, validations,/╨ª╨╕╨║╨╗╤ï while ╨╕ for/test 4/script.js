function askNumber(){
    return +prompt('Enter number more then 100',100);
}

let number ;
do{
    number = askNumber();
    if(!Number(number)
    || number > 100){
        alert('goodbye');
    }
}while (number <= 100);