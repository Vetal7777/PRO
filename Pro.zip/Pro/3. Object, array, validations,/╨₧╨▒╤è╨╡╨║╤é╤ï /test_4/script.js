// до вызова функции
let menu = {
    width: 200,
    height: 300,
    title: "My menu"
};

//Создайте функцию multiplyNumeric(obj),
// которая умножает все числовые свойства объекта obj на 2.

function multiplyNumeric(obj){
    for(let key in obj){
        if (Number(obj[key])){
            obj[key] = obj[key] * 2 ;
        }
        alert(obj[key]);
    }
}

multiplyNumeric(menu);