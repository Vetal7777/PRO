let schedule = {};

function isEmpty(obj) {
    for (let key in obj) {
        // если тело цикла начнет выполныяться - значит в объекте есть свойства
        return false;
    }
    return true;
}

alert(isEmpty(schedule));