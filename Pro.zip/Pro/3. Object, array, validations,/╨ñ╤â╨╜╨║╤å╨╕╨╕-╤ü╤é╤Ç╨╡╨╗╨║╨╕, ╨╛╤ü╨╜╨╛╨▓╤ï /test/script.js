let ask = (question, yes, no) =>{
    switch (confirm(question)){
        case true:
            yes();
            break;

        default:
            no();
    }
}

ask(
    "Вы согласны?",
    () => alert("Вы согласились.") ,
    () => alert("Вы отменили выполнение.")
);