const tabs = new Tab(document
    .querySelector('.tab-container'),
    {eventType: 'mouseover'});