class PersonClass {
    constructor(name,age) {
        this.name = name;
        this.age = age;
    }
    //Контруктор нам позволяет поумолчаю закинуть какието данные
    sayHi(){
        console.log('Hello from',this.name);
    }
}


const adam = new PersonClass('Adam',26);
const eva = new PersonClass('Eva',22);

console.log(adam);
console.log(eva);
adam.sayHi();
eva.sayHi();