class PersonClass {
    //это класс
    //Пишеться в паскале
    sayHi(){
        console.log(`Hello ,${this.name}`);
    };
    //мы можем создавать методы точно также
    //как и в конструкторе
    name = 'Adam';
    //поля класса записываются в instans
    // (не в prototype)
}

const adam = new PersonClass();
//Cоздали константу у которой класс PersonClass
//а значит он принял все методы данного класса
//все методы класса всегда попадают в Prototype
//без нашего вмештельства
adam.sayHi();//hello
console.log(adam);


function PersonConstructor(){}
PersonConstructor.prototype.sayHi = function (){
  console.log(`Hello from constructor`);
};

const adamConst = new PersonConstructor();
adamConst.sayHi();//Hello from constructor
console.log(adamConst);