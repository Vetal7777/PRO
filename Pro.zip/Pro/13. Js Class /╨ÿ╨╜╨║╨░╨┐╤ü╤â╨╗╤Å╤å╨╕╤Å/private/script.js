//private - не допустим к изменению извне
//(this._public) - по конвенции это private
//(#age) -приватная переменная


class PersonClass{
    #age = 11;
    constructor(name) {
        this.name = name;
    }
    get age(){
        return this.#age;
    }
    //Получаем
    set age(age){
        if(!age){
            console.log(`please enter valid age`);
            return;
        }
        this.#age = age;
    }
    //Задаем
}

const adam = new PersonClass('Adam');
console.log(adam.age);
adam.age = 21;
console.log(adam.age);