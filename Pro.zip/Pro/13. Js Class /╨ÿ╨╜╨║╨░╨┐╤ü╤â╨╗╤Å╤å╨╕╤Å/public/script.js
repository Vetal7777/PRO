//public - доступна модификация

class PersonClass{
    age = 11;
    constructor(name) {
        this.name = name;
    }
}

const adam = new PersonClass('Adam');
console.log(adam.age);