//readonly - вообще не модифицируется

class PersonClass{
    #age = 11;
    constructor(name) {
        this.name = name;
    }
    get age(){
        return this.#age;
    }
}

const adam = new PersonClass('Adam');
console.log(adam.age);