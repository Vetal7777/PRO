//1 Наследование
//2 Полиморфизм
//3 Инкапсуляция
function PersonConstructor(name){
    this.name = name;
}

PersonConstructor.prototype.sayHi = function (){
    console.log(`Hello from constructor`, this.name,this.age);
}


function Man(name,age){
    this.age = age;
    PersonConstructor.call(this,name);
    this.digg = function (){
        console.log(`I'm digging`);
    }
}

Man.prototype = new PersonConstructor();

const adamConst = new Man('Adam',22);
const joe = new Man('Joe',33);

console.log(adamConst);
joe.sayHi();
adamConst.sayHi();