class PersonClass{
   id = null;
   static size = 55;
   constructor() {
       PersonClass.createId.call(this);
   }
   static createId(){
       return this.id = PersonClass.size + Math.random();
   }
}

const adam = new PersonClass();
console.log(adam);