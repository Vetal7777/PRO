//1 Наследование
//2 Полиморфизм
//3 Инкапсуляция

class PersonClass {
    constructor(name) {
        this.name = name;
    }
    sayHi(){
        console.log('Hello from',this.name);
    }
}

class ManClass extends PersonClass{
    constructor(name,age) {
        super(name);
        this.age = age;
    }
    digg(){
        console.log('digg');
    }
}

const adam = new ManClass('Adam',26);
const eva = new ManClass('Eva',22);

console.log(adam);
console.log(eva);
adam.sayHi();