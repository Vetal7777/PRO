class PersonClass{
    constructor(name) {
        this.name = name;
    }
    sayHi(){
        console.log(`Hello from ${this.name}`);
    }
}

class ManClass extends PersonClass{
    constructor(name,age) {
        super(name);
        this.age = age;
    }
    digg(){
        console.log('digg');
    }
    sayHi() {
        super.sayHi();
        //Сначала выполниться sayHi PersonClass
        console.log('Hello like a mando it' ,this.age);
        //потом перезаписанный метод
    }
}

const adam = new ManClass('Adam',22);

adam.sayHi();