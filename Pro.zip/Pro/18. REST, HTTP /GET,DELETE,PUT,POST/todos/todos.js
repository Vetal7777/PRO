class Todos{
    #endpoint = `https://jsonplaceholder.typicode.com/todos`;
    getTodos(){
        return fetch(this.#endpoint).then(r => r.json());
    }
    //GET
    //Возвращает массив объектов которые мы запросили
    deleteTodo(id){
        return fetch(`${this.#endpoint}/${id}`,{
            method: 'DELETE',// GET, POST, PUT, DELETE, etc.
            headers:{
                'Content-Type': 'application/json'
                //'Content-Type' : application/x-ww-form-urlencoded
            },
        }).then(r => r.json());
    }
    //DELETE
    //Возвращает статус запроса
    createTodo(todo){
        return fetch(this.#endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(todo),
        })
            //POST
            .then(promise => promise.json())
            .then(result => console.log(result));
    }
    //Возвращает объект который мы публикуем
    putTodo(todo){
        return fetch(`${this.#endpoint}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(todo),
        })
            //PUT
            .then(promise => promise.json())
            .then(result => console.log(result));
    }
    //Возвращаем объект который мы изменили
}