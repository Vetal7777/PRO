const todoC = document.querySelector('.todo-cont');
const itemC = document.querySelector('.item-cont');
let todos = [];
let currentTodo = null;

todoC.addEventListener('click',onTodoCLick);

const todo = new Todos();
const user = new Users();

todo.getTodos().then(r => {
    todos = r.splice(0,40);
    renderTodo(todos);
});

function renderTodo(data){
    const html = data.map(e => `<li id=${e.id}>${e.title}</li>`)
    todoC.innerHTML = html.join('');
}

function onTodoCLick(e){
    todo.deleteTodo(e.target.id).then(r => {
        console.log(`ON DELETE`,r);
        todos = todos.filter(t => t.id !== +e.target.id);
        renderTodo(todos);
    })
}

function renderSingleTodo(user,todo){
    itemC.innerHTML = `<div>TITLE:${todo.title}</div><div>AUTHOR:${user.name}</div>`;
}