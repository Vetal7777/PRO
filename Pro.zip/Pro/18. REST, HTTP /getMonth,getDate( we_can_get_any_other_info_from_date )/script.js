const date = new Date(1653388693016);

console.log('Date',date);

console.log('Day',date.getDate());
console.log('Month',date.getMonth())