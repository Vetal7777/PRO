class GitHub{
    #endpoit = `https://api.github.com/users/`;
    //начало url для нашего fetch
    getUser(login){
        //login - login который мы добовляем в ссылку
        return fetch(this.#endpoit + login)
            //добавляем в изначальноую ссылку endpoit + login
            .then((r) => {
                if(r.status === 200){
                    return r.json();
                }
                return Promise.reject(r.status);
            });
        //получили Promise
    }
}