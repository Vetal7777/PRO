const inpE = document.getElementById('inp');
//наш input
inpE.value = 'vetal7777';
//Для теса
const containerE = document.getElementById('name');
//наш контейнер с результатом
const errorE = document.getElementById('err');
//Контейнер с ошибкой
const btnE = document.getElementById('btn');
//контейнер с кнопкой
let user = null;

const git = new Todos();
//cоздаем новую ссылку
// - без юзера

btnE.addEventListener('click',onFind);
//при клике на кнопку запускается функция onFind

const ERROR_MSG = {
    404: 'Not found',
    500: 'Server is unvailable',
};

function onFind(e){
    git
        .getUser(inpE.value)
        .then(u => {
            user = u;
            console.log(u);
            renderData(user);
        })
        .catch(e => renderError(e));
}

function renderData(data){
    containerE.innerHTML = data.repos_url;
}

function renderError(errorCode){
    errorE.innerHTML = ERROR_MSG[errorCode];
}