const dateTest = '2022-05-24T10:38:13.016Z';

const msDateTest = Date.parse(dateTest);
//получаем дату в милисекундах

console.log(msDateTest);