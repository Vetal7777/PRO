const dateTest = '2022-05-24T10:38:13.016Z';

const msDateTest = 1653388693016;

let date = new Date(msDateTest);

console.log('On miliseconds',date);

date = new Date(dateTest);

console.log('On date',date);
//Дату можно создавать и с милисекунды и с любых других параметров