//Деструкторизация массива


    const c = ['Bob', 'Anderson', 18];
    const d = c ;

    d[2] = 12;

    console.log(c);// Bob, Anderson, 12
    console.log(d);// Bob, Anderson, 12

    let a = ['Bob', 'Anderson', 18];

    let [firstName,familiya,vozrast] = a;

    vozrast = 12;

    console.log(a);// Bob, Anderson, 18
    console.log(vozrast);// Bob, Anderson, 12



// -------------------------------------

    //так можно скопирывать данные из обьекта
    //но лучше так не делай

    const user = {
        firstName: 'Bob',
        age:111,
        addres:{
            city:'Kyiv',
            country:'Ukraine',
        },
    };

    const {age,firstName:name,lastName = 'Smith',addres:{city,country}} = user;

    console.log(user);
    console.log(name);
    console.log(lastName);
    console.log(age);
    console.log(city);
    console.log(country);

// -------------------------------------

const b = ['Vasya','Petrov',22,'Ukraine','Kyiv'];

const [nameB,,ageB,...otherB] = b;

console.log(nameB);
console.log(ageB);
console.log(otherB);