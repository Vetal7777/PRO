const products = [
  {
    price: 200,
    name: "TV",
    amount: 3,
    discaunt: 5,
    availableIn: ["Odessa", "Kyiv", "Lviv"],
  },
  {
    price: 300,
    name: "Phone",
    amount: 5,
    discaunt: 10,
    availableIn: ["Baden-baden", "Kyiv", "Lviv"],
  },
  {
    price: 200,
    name: "oven",
    amount: 10,
    discaunt: 13,
    availableIn: ["Chernobaivka", "Lviv", "Zaporoje"],
  },
  {
    price: 400,
    name: "iron",
    amount: 32,
    discaunt: 0,
    availableIn: ["Kharkiv", "Vilnus", "Mykolaiv"],
  },
];

// Есть вот такой список продуктов.
//Нужно получить следующие переменные:
      // сумму всех денег по продуктам
      // Сумму всех денег по продуктам с учетом скидки
      // список всех городов где представлены продукты
      // список городов, по которым продукты пересекаются (Львов, Киев итд)


//elem - massive[i]
//acc = result

function calculateSumMoneyForGoods(massive){
  return massive.reduce((acc,elem)=> acc += (elem.price * elem.amount),0);
}

function calculateSumMoneyForGoodsWithDiscount(massive){
  return massive.reduce((acc,elem)=> acc += (elem.price * elem.amount * ((100 - elem.discaunt)/100)),0)
}

function createUlTowns(massive){
  const towns = massive.reduce((acc,elem) => {
    acc.push(elem.availableIn);
    return acc;
    },[]).flat();
  const result = towns.filter((elem, index) => {
    return towns.indexOf(elem) === index;
  });
  return result;
}

function createUlTownsDuplicate(massive){
  const towns = massive.reduce((acc,elem) => {
    acc.push(elem.availableIn);
    return acc;
  },[]).flat();
  const result = towns.reduce((acc,elem,index) => {
    if (towns.indexOf(elem) !== index && !acc.includes(elem)){
      acc.unshift(elem);
    }
    return acc;
  },[]);
  return result;
}

const productsData = [
  {
    sumMoneyForGoods: calculateSumMoneyForGoods(products),
    sumMoneyForGoodsWithDiscount: calculateSumMoneyForGoodsWithDiscount(products),
    ulTowns: createUlTowns(products),
    ulTownsDupl: createUlTownsDuplicate(products),
  }
];

console.log(productsData);