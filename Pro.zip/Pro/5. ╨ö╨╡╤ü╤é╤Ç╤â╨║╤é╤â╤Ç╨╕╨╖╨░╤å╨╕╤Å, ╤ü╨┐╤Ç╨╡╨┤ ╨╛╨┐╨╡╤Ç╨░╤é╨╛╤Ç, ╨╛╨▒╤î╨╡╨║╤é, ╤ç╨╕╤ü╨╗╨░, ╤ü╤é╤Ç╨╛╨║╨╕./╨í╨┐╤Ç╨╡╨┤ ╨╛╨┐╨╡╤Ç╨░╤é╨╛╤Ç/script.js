// Спред оператор ...

const b = [1,2,3,4,5];

const [z,...x] = b;

console.log(b);
console.log(z);
console.log(x);


//------------------------------------

const user = {
    firstName: 'Bob',
    lastName: 'Anderson',
    age:  111,
    addres: {
        city: 'Kiyev',
        country: 'Ukraine',
    },
    addresSecond: {
        city: 'Kiyev',
        country: 'Ukraine',
    },
};

const userNew = {...user};
userNew.addresSecond = {...user.addresSecond};
userNew.firstName = 'Alex';
userNew.addres.city = 'Kharkov';// изменит и в user
userNew.addresSecond.city = 'Kharkov';// изменит только в том что нужно нам

console.log(user);
console.log(userNew);

