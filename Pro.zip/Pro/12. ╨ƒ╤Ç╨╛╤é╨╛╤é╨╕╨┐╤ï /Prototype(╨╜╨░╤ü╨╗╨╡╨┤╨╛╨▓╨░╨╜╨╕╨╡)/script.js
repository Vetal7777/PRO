function Person(){
    this.name = '';
    this.sayHi = function (){
        console.log('Hi');
    }
}
//Функция Person человек
// - у которого есть имя name
// - который умеет здороваться с помощью sayHi()

function Man(){
    this.dickHoles = function (){
        console.log('I ca dick holes');
    };
}
//Функция Man мужчина
// - который умеет dickHoles()

function Women(){
    this.canRest = function (){
        console.log('I am resting');
    };
}
//Функция woman девушка
// - который умеет canRest()

Man.prototype = new Person();
Women.prototype = new Person();
//Man и Woman они оба Person
//- наследуют все его свойства

function OldMan(){
    this.pension = 100;
}

OldMan.prototype = new Man();
//теперь прототипы и man и person но man в консоле не видно
//видно функции man

const adam = new Man();
//adam - мальчик человек
const eva = new Women();
//eva - девушка человек

console.log(adam);
console.log(eva);
adam.sayHi();
eva.sayHi();
//Как все люди оба говорят привет
adam.dickHoles();
eva.canRest();
//но каждый может исполнять то что умеет его пол
adam.canRest();
eva.dickHoles();
//девочка не может делать то что мужчина и наоборот