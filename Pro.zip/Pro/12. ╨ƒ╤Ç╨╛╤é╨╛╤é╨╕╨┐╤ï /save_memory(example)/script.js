function TodoConcstructor() {
    this.todoList = [];
}
//Конструктор в котором пустой массив todoList

TodoConcstructor.prototype.setTodo = function (todo){
    const validateTodo = this.validateTodo(todo);
    this.todoList.push(this.createTodo(validateTodo));
};
TodoConcstructor.prototype.validateTodo = function (todo){
    if (!todo.trim()){
        console.log(`it's bad todo`);
        return ;
    }
    return todo;
};
TodoConcstructor.prototype.createTodo = function (todo){
    return{
        id: +Math.random().toFixed(3),
        title:todo,
    }
};
TodoConcstructor.prototype.renderTodo = function (){
    this.todoList.forEach((t) => console.log(t));
};

//Все его методы мы создали в prototype
//чтобы сэкономить память
const todo = new TodoConcstructor();

console.log(todo);

todo.setTodo('first todo');
todo.setTodo('abra todo');
todo.setTodo('last todo');

todo.renderTodo();