function TodoConcstructor(){
    //функция Todo
    this.todoList = [];
    //this массив todoList
    this.setTodo = function (todo){
        //this функция setTodo
        const validateTodo = this.validateTodo(todo);
        //константа validateTodo = результат функции validateTodo
        //либо underfined либо todo
        this.todoList.push(this.createTodo(validateTodo));
    //в this todoList (массив)
    // добовляем то что получилось в результате функции createTodo
    };
    //Функция
    // - запускает функцию validateTodo(todo)
    // - и добовляет результат функции createTodo(validateTodo(todo))
    // в массив this.todoList
    this.validateTodo = function (todo){
        //this функция validateTodo
        if (!todo.trim()){
            //если todo пустая
            console.log(`it's bad todo`);
            //то в консоли выводится текст ошибки
            return ;
        //выходим из функции
        }
        return todo;
    //в любом другом случаии просто возвращаем todo
    };
    //Функция
    // - если свойство функции (todo) пустое
    //то оно возвращает в консоль ошибку
    // - если она хранит значение то функция возвращает свойство
    this.createTodo = function (todo){
        //this функция createTodo
        return{
            //возвращает обьект
            id: +Math.random().toFixed(3),
            //свойтво id , key - рандомное число до тысячных дробей
            title:todo,
            //title  =  todo
        }
    };
    //Функция
    // - создает обьект с рандомным id
    // - и с title = cвойству функции (todo)
    this.renderTodo = function (){
        this.todoList.forEach((t) => console.log(t));
    };
    //Функция
    // - показывает в консоле все обьекты
}

const todo = new TodoConcstructor();

todo.setTodo('first todo');
todo.setTodo('abra kadabra');
todo.setTodo('last todo');

todo.renderTodo();