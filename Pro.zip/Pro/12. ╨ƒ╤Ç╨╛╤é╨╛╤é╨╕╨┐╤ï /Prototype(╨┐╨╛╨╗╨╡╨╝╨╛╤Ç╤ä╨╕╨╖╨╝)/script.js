function Person(){
    this.name = '';
    this.sayHi = function (){
        console.log('Hi');
    };
    this.canCook = function (){
        console.log('I can cook');
    }
}
//Функция Person человек
// - у которого есть имя name
// - который умеет здороваться с помощью sayHi()
// - Умеют говорть что умееют готовить
//с помощью функции canCook 'I can cook'

function Man(){
    this.tie = 'black';
    this.dickHoles = function (){
        console.log('I ca dick holes');
    };
}
//Функция Man мужчина
// - который умеет dickHoles()

function Women(){
    this.canRest = function (){
        console.log('I am resting');
    };
}
//Функция woman девушка
// - который умеет canRest()

Man.prototype = new Person();
Women.prototype = new Person();
//Man и Woman они оба Person
//- наследуют все его свойства

Man.prototype.canCook = function (){
    console.log('I cook perfrectly');
}
Women.prototype.canCook = function (){
    console.log('I am the best cook');
}
//Изменям наследованную функцию от person
//у каждого

const adam = new Man();
const eva = new Women();
//eva - девушка человек

adam.canCook();//'I cook perfrectly'
eva.canCook();//'I am the best cook'