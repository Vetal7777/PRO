function User(name){
    this.name = name;
    this.sayHi = () => {
        console.log('hello from',this.name);
    };
}

const vasya = new User('Vasya');
const irina = new User('Irina');
const sayHello = vasya.sayHi;

irina.sayHi = sayHello;

irina.sayHi();