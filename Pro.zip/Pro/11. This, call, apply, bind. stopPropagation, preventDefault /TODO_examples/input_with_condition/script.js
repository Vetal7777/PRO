const inpE = document
    .getElementById('txt');
const btn = document
    .getElementById('btn');
const errorE = document
    .querySelector('.error-cont');

inpE.addEventListener('keyup',validateTodo);
btn.addEventListener('click',onAddTodo);
btn.disabled = true;
function onAddTodo(e){
    console.log('qdsdad');
}

function validateTodo(e){
    if(!e.target.value.trim()){
        errorE.innerText = '';
        btn.disabled = true;
        return;
    }
    if(e.target.value.trim().length <= 3){
        errorE.innerText = 'Error , lenght should be > 3';
        btn.disabled = true;
        return;
    }

    errorE.innerText = '';
    btn.disabled = false;
}