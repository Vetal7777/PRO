const inpE = document
    .getElementById('txt');
//input
const btn = document
    .getElementById('btn');
//buttom
const errorE = document
    .querySelector('.error-cont');
//error контейнер
const contE = document
    .querySelector('.container');
//todo контейнер

inpE.addEventListener('keyup',validateTodo);
//После того как отпустил клавищу на клавиатуре
//вызывается функция validateTodo
btn.addEventListener('click',onAddTodo);
//при клике на кнопку вызывается функци onAddTodo

btn.disabled = true;
//Кнопка поумолчанию в состоянии disabled

function onAddTodo(e){
    const element =
        `<div class="item">
            <span class="delete">x</span>
            ${inpE.value}
        </div>`;
    //Наш шаблон todo
    //inpE.value - это то что мы написали в input
    contE.innerHTML += element;
    //внутренний html contE элемента
    //будет равнятся тому что внтури уже + element
    inpE.value = '';
    //Чистим наш input
    inpE.focus();
    //Делаем фокус на наш input
}
//Функция :
// - Создает todo с тем текстом что написал пользователь
// - Чистит после этого сам input
// - Фокус ставит на input после всего этого

function validateTodo(e){
    if(!e.target.value.trim()){
        //Если в input нету текста или только пробелы
        errorE.innerText = '';
        //То текст внутри элемента errorE отсутвует
        btn.disabled = true;
        //Кнопка заблокирована
        return;
        //Выходим из функции
    }
    if(e.target.value.trim().length <= 3){
        //Если букв в input меньше или 3
        errorE.innerText = 'Error , lenght should be > 3';
        //То в элементе errorE текст 'Error ......'
        btn.disabled = true;
        //Кнопка заблокирована
        return;
        //Выходим из функции
    }
    errorE.innerText = '';
    //Во всех остальных ситуациях
    //Текст в errorE отствует
    btn.disabled = false;
    //Кнопка активна
}
//Функция:
// - Проверяет чтобы текст в input содержал больше чем 3 символа
// - Активирует кнопку при условии правильного ввода
// - Выводит текст ошибки в случае непрохождении валидации