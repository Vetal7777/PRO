const inpE = document
    .getElementById('txt');
//input
const btn = document
    .getElementById('btn');
//buttom
const errorE = document
    .querySelector('.error-cont');
//error контейнер
const contE = document
    .querySelector('.container');
//todo контейнер

inpE.addEventListener('keyup',validateTodo);
//После того как отпустил клавищу на клавиатуре
//вызывается функция validateTodo
btn.addEventListener('click',onAddTodo);
//при клике на кнопку вызывается функци onAddTodo
contE.addEventListener('click',onTodoClick);
//при клике на кнопку вызывается функци onTodoClick
btn.disabled = true;
//Кнопка поумолчанию в состоянии disabled

function onTodoClick(e){
    [...e.target.attributes]
        //Копия атрибутов элемента на который мы нажали
        .forEach((el) => {
            //выполняем действие на каждый атрибут
            if(el.value === 'todo'){
                //если значение атрибута = todo
                completeTodo(e.target);
                //то вызываем функцую на элемент
                //на который первоначально нажали
            }
            if(el.value === 'delete'){
                //если значение атрибута = delete
                deleteTodo(e.target);
                //то вызываем функцую на элемент
                //на который первоначально нажали
            }
    });
}
//Функция :
// - в данной функции прописсано какие функции вызывать
    //при какои нажатии

function deleteTodo(elem){
    elem
        .closest('.item')
        //Находим родителя элемента с классом item
        .remove();
        //удаляем данный контейнер
    //Ищем родителя элемента с селектоором .item
}
//Функция :
// - Доходит до родителя данного элемента и удаляет его

function completeTodo(elem){
    elem.classList.toggle('complite');
}
//Функция :
// - Добовляет и удаляет класс complite у элемента

function onAddTodo(e){
    const element =
        `<div name='todo' class="item">
            <span name='delete' class="delete">x</span>
            ${inpE.value}
        </div>`;
    //Наш шаблон todo
    //inpE.value - это то что мы написали в input
    contE.innerHTML += element;
    //внутренний html contE элемента
    //будет равнятся тому что внтури уже + element
    inpE.value = '';
    //Чистим наш input
    inpE.focus();
    //Делаем фокус на наш input
}
//Функция :
// - Создает todo с тем текстом что написал пользователь
// - Чистит после этого сам input
// - Фокус ставит на input после всего этого

function validateTodo(e){
    if(!e.target.value.trim()){
        //Если в input нету текста или только пробелы
        errorE.innerText = '';
        //То текст внутри элемента errorE отсутвует
        btn.disabled = true;
        //Кнопка заблокирована
        return;
        //Выходим из функции
    }
    if(e.target.value.trim().length <= 3){
        //Если букв в input меньше или 3
        errorE.innerText = 'Error , lenght should be > 3';
        //То в элементе errorE текст 'Error ......'
        btn.disabled = true;
        //Кнопка заблокирована
        return;
        //Выходим из функции
    }
    if(e.keyCode === 13){
        onAddTodo();
    }
    //Если мы нажымаем Enter в input то вызываем функцию
    //onAddTodo
    errorE.innerText = '';
    //Во всех остальных ситуациях
    //Текст в errorE отствует
    btn.disabled = false;
    //Кнопка активна
}
//Функция:
// - Проверяет чтобы текст в input содержал больше чем 3 символа
// - Активирует кнопку при условии правильного ввода
// - Выводит текст ошибки в случае непрохождении валидации