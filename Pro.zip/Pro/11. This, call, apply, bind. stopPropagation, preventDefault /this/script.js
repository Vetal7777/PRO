function User(name){
    this.name = name;
    this.sayHi = function (){
        console.log('hello from',this.name);
    };
}

const vasya = new User('Vasya');
const irina = new User('Irina');
vasya.sayHi();
irina.sayHi();
console.log(vasya);
console.log(irina);