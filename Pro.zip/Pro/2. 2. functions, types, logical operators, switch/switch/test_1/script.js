let login = prompt('Enter your login','admin');

switch (login){
    case 'admin':
        let password = prompt('Enter your password', 'I am legend');

        switch (password){
            case 'I am legend':
                alert('Hello');
                break;

            case null:
                alert('Canceled');
                break;

            default:
                alert('It is not correct answer');
                break;
        }

        break;

    case null:
        alert('Canceled');
        break;

    default:
        alert('I do not know you');
        break;
}