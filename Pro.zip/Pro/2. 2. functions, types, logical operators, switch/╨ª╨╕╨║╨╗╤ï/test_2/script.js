for (let i = 0; i < 3; i++) {
    alert( `number ${i}!` );
}

//переписали на while

let i = 0;

while (i < 3){
    alert(`number ${i}!`);
    i++;
}