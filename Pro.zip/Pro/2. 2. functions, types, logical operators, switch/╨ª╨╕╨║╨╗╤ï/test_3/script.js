let value ;

do {
    value = prompt('Enter the number',101);
}while (value < 100 && value != null )