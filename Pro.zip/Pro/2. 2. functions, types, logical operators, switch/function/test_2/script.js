function min(a,b){
    return (a < b) ? a : (a > b) ? b : 'fuck';
}
alert(min(2,4));