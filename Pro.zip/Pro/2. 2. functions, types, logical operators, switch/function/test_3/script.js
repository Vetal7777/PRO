function pow(x,n){
    switch (Number.isInteger(n)){
        case false:
            return 'You are have a mistake';
            break;

        default:
            return x**n;
    }
}

alert(pow(2,3));