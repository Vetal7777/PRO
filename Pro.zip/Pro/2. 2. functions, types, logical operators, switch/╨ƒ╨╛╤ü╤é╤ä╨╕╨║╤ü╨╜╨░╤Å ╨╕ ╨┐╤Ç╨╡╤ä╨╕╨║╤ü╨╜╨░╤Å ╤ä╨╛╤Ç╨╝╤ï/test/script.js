let a = 1, b = 1;

let c = ++a;
let d = b++;
// a = 2; b = 2; c = 2; d = 1;