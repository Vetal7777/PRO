function askNumbers(inputsString){
    return +prompt('Enter the '+inputsString+' number ', '1');
}

function askOperation (){
    return prompt('Select the operation, please ( * , + , - , / )','+');
}

function calculation(a,b,c){
    if (c === '+'){
        return a + b;
    }else if(c === '-'){
        return a - b;
    }else if(c === '*'){
        return a * b;
    }else if(c === '/'){
        return a / b;
    }else
        return 'You have a mistake;'
}

function showResult(){
    const firstNumber = askNumbers('first');
    if (Number(firstNumber)){
        const secondNumber = askNumbers('second');
        if (Number(secondNumber)){
            const operation = askOperation();
            switch (operation){
                case '+':
                case '-':
                case '/':
                case'*':
                    return  `${firstNumber} ${operation} ${secondNumber} = ${calculation(firstNumber,secondNumber,operation)}`;
                    break;
                default:
                    return 'You have a mistake';
                    break;
            }
        }else
            return 'You have a mistake';
    }else
        return 'You have a mistake';
}

alert(showResult());

