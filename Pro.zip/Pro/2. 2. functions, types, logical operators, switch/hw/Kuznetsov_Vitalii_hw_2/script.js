function askNumbers(inputsString){
    return +prompt('Enter the '+inputsString+' number ', '1');
}

function askOperation (){
    return prompt('Select the operation, please ( * , + , - , / )','+');
}

function sum(firstNumber, secondNumber){
    return firstNumber + secondNumber;
}

function subtraction(firstNumber, secondNumber){
    return firstNumber - secondNumber;
}

function multiplication(firstNumber, secondNumber){
    return firstNumber * secondNumber;
}

function division(firstNumber, secondNumber){
    return firstNumber / secondNumber;
}

function calculation(){
    const operation = askOperation();
    const firstNumber = askNumbers('first');
    if( !Number(firstNumber)){
        return 'Enter first number';
    }
    const secondNumber = askNumbers('second');
    if( !Number(secondNumber)){
        return 'Enter second number';
    }
    let result;
    switch (operation){
        case '+':
            result = sum(firstNumber, secondNumber);
            break;

        case '-':
            result = subtraction(firstNumber, secondNumber);
            break;

        case '/':
            result = division(firstNumber, secondNumber);
            break;

        case '*':
            result = multiplication(firstNumber, secondNumber);
            break;

        default:
            return 'You have a mistake';
    }
    if (result === undefined){
        return 'You have a mistake';
    }else {
        return `${firstNumber} ${operation} ${secondNumber} = ${result}` ;
    }
}

const mathOperationResult = calculation();
alert(mathOperationResult);