const users = [
    {
        name: 'Bob',
        age: 27,
        address:{
            country:'USA',
            city:'LA'
        },
        marks:[2,3,5,4,2,3,1,5]
    },
    {
        name: 'July',
        age: 21,
        address:{
            country:'Ukraine',
            city:'Kiev'
        },
        marks:[4,4,5,4,3,4,3,5]
    },
    {
        name: 'Monya',
        age: 15,
        address:{
            country:'Ukraine',
            city:'Odessa'
        },
        marks:[5,1,5,1,5,1,5,1]
    },
    {
        name: 'Vsevolod',
        age: 19,
        address:{
            country:'Ukraine',
            city:'Lviv'
        },
        marks:[3,4,5,3,1,2,4,6]
    },
];


//1
const isNotAdult = users.filter(function (element, index,array){
    if (element.age <= 18){
        return element;
    }
})

console.log(isNotAdult);
//2
const foreignStudents = users.filter(function (element, index,array){
    return (element.address.country !== 'Ukraine');
})

console.log(foreignStudents);


//3
let usersNew = JSON.parse(JSON.stringify(users));

usersNew.map(function (element, index,array){
    (element.age >= 18) ? element.isAdult = true : element.isAdult = false;
    element.averageMark = (element.marks.reduce((sum, current) => sum + current)) / element.marks.length;
    return element;
})

console.log(usersNew);

//4
let averageMark = users.map(function (element,index,array){
    return (element.marks.reduce((sum, current) => sum + current)) / element.marks.length;
})

averageMark = (averageMark.reduce((sum, current) => sum + current)) / averageMark.length;

console.log(averageMark);


//5
const addresses = {
    countries:[],
    cities:[],
};

addresses.countries = users.map(function (element, index,array){
    return element.address.country;
})

addresses.cities = users.map(function (element, index,array){
    return element.address.city;
})

function searchAndDeleteDoubleElement(a){
   a.sort();
    for(let i = +(a.length - 1); i > 0; i--){
        if(a[i] === a[i-1]){
            a.splice(i-1,1);
        }
    }
}

searchAndDeleteDoubleElement(addresses.countries);
searchAndDeleteDoubleElement(addresses.cities);

console.log(addresses);