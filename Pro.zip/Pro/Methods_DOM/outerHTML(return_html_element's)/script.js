const testE = document.getElementById('test');

console.log(testE.outerHTML);

console.log(testE);