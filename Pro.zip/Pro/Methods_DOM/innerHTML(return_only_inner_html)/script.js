const testE = document.getElementById('test');

console.log(testE.innerHTML);

console.log(testE);