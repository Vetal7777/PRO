const orig = '   foo  ';

console.log(orig);//'  foo  '

const trim = orig.trim();

console.log(trim); // 'foo'
