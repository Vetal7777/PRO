const textE = document.getElementById('text');

const btn = document.querySelector('#btn');

function onClick(){
    textE.innerText = 'done!';
    //меняем наш текст
}

btn.addEventListener('click',onClick);
