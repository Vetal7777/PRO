const test = document.getElementById('list-container');

test.addEventListener('click',onClick);

function onClick(event){
    const elem = event.target;
    elem.classList.toggle('green');
}