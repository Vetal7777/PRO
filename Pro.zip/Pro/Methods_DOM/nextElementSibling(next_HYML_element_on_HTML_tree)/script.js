const testE = document.getElementById('test');

console.log(testE.nextElementSibling);//TestE child