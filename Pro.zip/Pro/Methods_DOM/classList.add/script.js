const r = document.getElementById('root');

console.log(r.classList);

r.classList.add('smile');
//добавляем класс smile

console.log(r.classList);