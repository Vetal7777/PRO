const test = document.querySelector('p');
test.closest('#simple').remove();