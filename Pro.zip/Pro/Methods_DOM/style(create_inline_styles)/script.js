const r = document.getElementById('root');

console.log(r.style.color);

r.style.color = 'pink';

console.log(r.style.color);
