const r = document.getElementById('root');

console.log(r.classList);
//возвращает все классы у этого элемента