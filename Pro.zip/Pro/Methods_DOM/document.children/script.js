console.log(document.children);
console.log(document.children[0]);//html
console.log(document.children[0].children[1]);//body