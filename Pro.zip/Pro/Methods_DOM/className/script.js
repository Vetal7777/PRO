console.log(document.getElementById('root'));

console.log(document.getElementById('root').className);
//возвращает нам строку с классами у этого элемента

document.getElementById('root').className = 'green';
//меняем все классы на один класс green (удаляет все остальные классы)

console.log(document.getElementById('root').className);

