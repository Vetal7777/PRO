console.log(document.getElementsByTagName('li'));//div
