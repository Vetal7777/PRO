console.log(document.getElementsByClassName('item'));//class
