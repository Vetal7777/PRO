console.log(document.querySelectorAll('.root div.aaa'));//
