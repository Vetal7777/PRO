const textE = document.getElementById('text');

const btn = document.querySelector('#btn');

const ulE = document.getElementById('list');

let pressCounter = 1;

function onClick(){
    ++pressCounter;
    const liE = document.createElement('li');
    liE.textContent = pressCounter;
    ulE.append(liE);
    console.log(liE);
}

btn.addEventListener('click',onClick);

console.log(ulE);