const r = document.getElementById('root');

console.log(r.classList);

r.classList.toggle('smile');
//добавляем класс smile

console.log(r.classList);

r.classList.toggle('smile');
//удаляем класс smile

console.log(r.classList);