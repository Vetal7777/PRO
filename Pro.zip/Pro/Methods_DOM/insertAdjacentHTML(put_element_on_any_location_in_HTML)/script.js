const test = document.getElementById('test');
test.insertAdjacentHTML('beforebegin','<span>Before begin</span>');
test.insertAdjacentHTML('afterbegin','<span>After begin</span>');
test.insertAdjacentHTML('beforeend','<span>Before end</span>');
test.insertAdjacentHTML('afterend','<span>After end</span>');

console.log(document.querySelector("body"));