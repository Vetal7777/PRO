const r = document.getElementById('root');

console.log(r.classList);

r.classList.remove('text');
//удаляем класс text

console.log(r.classList);