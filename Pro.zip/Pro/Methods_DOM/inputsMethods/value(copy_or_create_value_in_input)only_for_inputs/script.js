const btn = document.querySelector('#btn');

const inpE = document.getElementById('inp');

inpE.value = 'what do you want?';

function onClick(){
    console.log(inpE.value);
}

btn.addEventListener('click',onClick);