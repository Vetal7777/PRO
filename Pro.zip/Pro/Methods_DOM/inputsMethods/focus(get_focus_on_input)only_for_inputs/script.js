const todoContainerE = document.getElementById('list-container');
const inpE = document.getElementById('inp');
const btnE = document.getElementById('btn');
const testE = document.getElementById('test');

btnE.addEventListener('click',onAddTodo);

function onAddTodo(){
    const text = inpE.value;
    const el = document.createElement('li');
    el.textContent = text;
    todoContainerE.append(el);
    inpE.value = '';
    inpE.focus();
    //мы говорим чтобы в конце функции фокусировка была
    //на наш input
}
