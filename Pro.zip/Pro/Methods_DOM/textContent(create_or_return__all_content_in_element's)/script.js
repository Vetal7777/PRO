const textE = document.getElementById('text');

const btn = document.querySelector('#btn');

function onClick(){
    textE.textContent = 'done!';
    //меняем наш текст
}

btn.addEventListener('click',onClick);
