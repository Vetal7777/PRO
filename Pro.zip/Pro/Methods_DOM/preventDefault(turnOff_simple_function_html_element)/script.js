let counter = 0;
const checkE = document
    .getElementById('inp');

checkE.addEventListener('click',(e) =>{
    if ( counter === 3 ){
        checkE.cheked = true;
    }else{
        e.preventDefault();
        counter++;
    }
});