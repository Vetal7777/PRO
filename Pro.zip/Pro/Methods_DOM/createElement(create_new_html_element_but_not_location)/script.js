const textE = document.getElementById('text');

const btn = document.querySelector('#btn');

let pressCounter = 0;

function onClick(){
    ++pressCounter;
    const liE = document.createElement('li');
    liE.textContent = pressCounter;
    console.log(liE);
}

btn.addEventListener('click',onClick);
