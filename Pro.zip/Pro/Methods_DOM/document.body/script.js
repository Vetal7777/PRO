console.log(document.body);//body
