console.log(document.forms);//form
