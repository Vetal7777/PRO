const test = document.getElementById('test');
test.remove();