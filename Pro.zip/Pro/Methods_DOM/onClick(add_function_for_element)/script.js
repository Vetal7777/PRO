const testE = document.getElementById('test');
testE.onclick = test;

function test(){
    alert('hello');
}
