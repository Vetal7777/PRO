document
    .querySelector('.out')
    .addEventListener('click',(e) => {
        console.log('OUT');
    });
document
    .querySelector('.second')
    .addEventListener('click',(e) => {
        console.log('SECOND');
    });
document
    .querySelector('.inner')
    .addEventListener('click',(e) => {
        e.stopPropagation();
        //Предотвращает вызов элементов выше
        //и ниже по уровню кроме данного
        console.log('INNER  ');
    });