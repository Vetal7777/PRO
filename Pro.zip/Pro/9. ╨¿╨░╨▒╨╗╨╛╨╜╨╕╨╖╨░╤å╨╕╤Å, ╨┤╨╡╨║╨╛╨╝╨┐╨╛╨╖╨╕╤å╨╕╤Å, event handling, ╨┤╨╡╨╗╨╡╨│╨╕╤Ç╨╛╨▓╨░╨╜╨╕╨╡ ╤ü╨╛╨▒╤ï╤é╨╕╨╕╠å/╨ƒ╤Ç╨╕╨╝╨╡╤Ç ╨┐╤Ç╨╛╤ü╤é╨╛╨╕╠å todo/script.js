const todoContainerE = document.getElementById('list-container');
//Наша тодо
const inpBodyE = document.getElementById('inp-body');
//Нащ инпут body
const btnE = document.getElementById('btn');
//Наша кнопка

btnE.addEventListener('click',onAddTodo);
//При клике запуская функцию onAddTodo

function onAddTodo(){
    const text = inpBodyE.value;
    if(!text.trim()){
        alert('Please add some text to todo');
        return;
    }
    const el = createElement('li');
    el.textContent = text;
    addElement(el,todoContainerE);
    clearValue(inpBodyE);
    inpBodyE.focus();
}

function createElement(tagName){
    return document.createElement(tagName);
}
function addElement(elem,container){
    container.append(elem);
}
function clearValue(inputE){
    inputE.value = '';
}
