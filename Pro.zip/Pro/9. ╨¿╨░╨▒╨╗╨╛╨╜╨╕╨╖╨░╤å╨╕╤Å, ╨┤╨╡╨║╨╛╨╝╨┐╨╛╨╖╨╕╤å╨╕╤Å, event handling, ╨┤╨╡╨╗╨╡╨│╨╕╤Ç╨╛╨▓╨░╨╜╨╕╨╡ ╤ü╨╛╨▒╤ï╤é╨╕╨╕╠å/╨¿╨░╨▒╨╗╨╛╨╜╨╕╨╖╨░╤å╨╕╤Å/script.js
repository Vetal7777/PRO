const todoContainerE = document.getElementById('list-container');
//Наша Todo поле с результатом
const inpBodyE = document.getElementById('inp-body');
//Нащ инпут body
const inpTitleE = document.getElementById('inp-title');
//Нащ инпут title
const btnE = document.getElementById('btn');
//Наша кнопка
const templateE = document.getElementById('template');
//Наш пример li

btnE.addEventListener('click',onAddTodo);
//При клике запуская функцию onAddTodo

function onAddTodo(){
    const body = inpBodyE.value;
    //body - содержимое inputBody
    const title = inpTitleE.value;
    //title - содержимое inputTitle
    if(!body.trim() || !title.trim()){
        alert('Please add some text to todo');
        return;
    }
    //Условие если пустой один из input
    const el = createToDoE(title,body);
    //Константа el - это теперь наш HTML который мы создали с
    //помощью функции
    addElement(el,todoContainerE);
    //Добавляем наш элемент в наш ul
    clearValue(inpBodyE);
    clearValue(inpTitleE);
//    Чистим все
}
function createToDoE(title,body){
    const el = templateE.innerHTML
        .replace('{{body}}',body)
        .replace('{{title}}',title);
    //ставит вместо элементов который мы указали - значения input
    return el;
}
//функция создает наш HTML код

function createElement(tagName){
    return document.createElement(tagName);
}
function addElement(elem,container){
    console.log('ELEMENT',elem);
    container.innerHTML += elem;
}
function clearValue(inputE){
    inputE.value = '';
}
