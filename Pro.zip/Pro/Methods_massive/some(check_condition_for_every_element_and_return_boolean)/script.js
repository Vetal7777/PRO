const arr = [22,33,'hello',34,'goodbye',55];

const stringArr = arr.some(function (element, index,array){
    return typeof element === 'string';
})

alert(stringArr);// true
