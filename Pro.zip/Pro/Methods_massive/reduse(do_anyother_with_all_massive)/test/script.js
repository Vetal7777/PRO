const arr = [22,33,'Bob',34,'Zak',55];

const newArr = arr.reduce(function (acc,element,index,arr){
    const user = {
        name : typeof element === 'string' ? element : 'NoName',
        age: typeof element === 'number' ? element : 21,
    };
    acc.push(user);
    return acc;
},[])

console.log(newArr);