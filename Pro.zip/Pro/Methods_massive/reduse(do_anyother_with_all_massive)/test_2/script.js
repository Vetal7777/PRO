const arr = [22,33,'Bob',34,'Zak',55];

let newArr = arr.reduce(function (acc,element,index,arr){
    typeof element === 'string' ? acc.users.push(element) : acc.marks.push(element);
    return acc;
}, {users:[],marks:[]});

console.log(newArr);