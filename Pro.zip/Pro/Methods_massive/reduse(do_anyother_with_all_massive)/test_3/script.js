const arr = [22,33,'Bob',34,'Zak',55];

let newArr = arr.reduce(function (acc,element,index,arr){
    return typeof element === 'number' ? (acc += element) : acc;
},0)

console.log(newArr);

newArr = arr.reduce(function (acc,element,index,arr){
    return typeof element === 'string' ? (acc += element) : acc;
},[])

console.log(newArr);