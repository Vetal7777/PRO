let vasya = { name: "Вася", surname: "Пупкин", id: 1 };
let petya = { name: "Петя", surname: "Иванов", id: 2 };
let masha = { name: "Маша", surname: "Петрова", id: 3 };

let users = [ vasya, petya, masha ];

console.log(users);

let usersMapped = users.reduce(function (acc,element,index,arr){
    const user = {
        fullName : element.name + ' ' + element.surname,
        id: element.id,
    };
    acc.push(user);
    return acc;
},[])

console.log(usersMapped);