const arr = [22,33,34,55];

arr.map(function (element, index,array){
    console.log(element);
})

