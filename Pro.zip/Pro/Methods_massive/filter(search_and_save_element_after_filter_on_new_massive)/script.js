const arr = [22,33,'hello',34,'goodbye',55];

const stringArr = arr.filter(function (element, index,array){
    return typeof element === 'string';
})

const numberArr = arr.filter(function (element, index,array){
    return typeof element === 'number';
})

console.log(stringArr);
console.log(numberArr);

// ------------------------------------------------


let users = [
    {id: 1, name: "Вася"},
    {id: 2, name: "Петя"},
    {id: 3, name: "Маша"}
];

// возвращает массив, состоящий из двух первых пользователей
let someUsers = users.filter(item => item.id > 1);

console.log(someUsers); // 2