function sortByAge(arr) {
    arr.sort((a, b) => a.age > b.age ? 0 : -1);
}

let vasya = { name: "Вася", age: 25 };
let petya = { name: "Петя", age: 30 };
let vetal = { name: "Маша", age: 28 };
let zhiva = { name: "Маша", age: 32 };
let anton = { name: "Маша", age: 54 };
let anjela = { name: "Маша", age: 65 };
let raksana = { name: "Маша", age: 76 };

let arr = [ vasya, petya, vetal, zhiva, anton, anjela, raksana ];

sortByAge(arr);

console.log(arr);