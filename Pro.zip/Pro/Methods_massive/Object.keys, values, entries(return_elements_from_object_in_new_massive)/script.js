let a = {
    name: 'John',
    age: 12,
}

let b = Object.keys(a);// свойства
let c = Object.values(a);// элементы
let d = Object.entries(a);//два массива (свойства, элементы)

console.log(b);
console.log(c);
console.log(d);