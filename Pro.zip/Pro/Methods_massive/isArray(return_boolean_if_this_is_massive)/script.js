alert(Array.isArray({})); // false

alert(Array.isArray([])); // true