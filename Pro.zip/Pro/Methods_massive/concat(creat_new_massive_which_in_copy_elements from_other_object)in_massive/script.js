let arr = [1, 2];

// создать массив из: arr и [3,4]
alert( arr.concat([3, 4]) ); // 1,2,3,4

// создать массив из: arr и [3,4] и [5,6]
alert( arr.concat([3, 4], [5, 6]) ); // 1,2,3,4,5,6

// создать массив из: arr и [3,4], потом добавить значения 5 и 6
alert( arr.concat([3, 4], 5, 6) ); // 1,2,3,4,5,6

//----------------------------------------------


arr = [1, 2];

let arrayLike = {
    0: "что-то",
    length: 1
};

alert( arr.concat(arrayLike) ); // 1,2,[object Object]


//----------------------------------------------



arr = [1, 2];

arrayLike = {
    0: "что-то",
    1: "ещё",
    [Symbol.isConcatSpreadable]: true,
    length: 2
};

alert( arr.concat(arrayLike) ); // 1,2,что-то,ещё