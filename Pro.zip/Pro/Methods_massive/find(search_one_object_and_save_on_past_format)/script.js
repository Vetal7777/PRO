const arr = [22,33,'hello',34,'goodbye',55];

const stringArr = arr.find(function (element, index,array){
    return typeof element === 'string';
})

console.log(stringArr);// hello


// ------------------------------------------------


let users = [
    {id: 1, name: "Вася"},
    {id: 2, name: "Петя"},
    {id: 3, name: "Маша"}
];

let user = users.find(item => item.id = 1);

console.log(user); // Вася