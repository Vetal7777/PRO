let arr = ["t", "e", "s", "t"];

let a = ( arr.slice(0, 2) ); // t,e (копирует с 1 до 3)

console.log( a);