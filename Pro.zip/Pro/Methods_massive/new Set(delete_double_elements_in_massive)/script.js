const test = [1,2,3,4,4,4,4,4,4,4,5];

const result = new Set(test);

console.log(result);// [1,2,3,4,5]