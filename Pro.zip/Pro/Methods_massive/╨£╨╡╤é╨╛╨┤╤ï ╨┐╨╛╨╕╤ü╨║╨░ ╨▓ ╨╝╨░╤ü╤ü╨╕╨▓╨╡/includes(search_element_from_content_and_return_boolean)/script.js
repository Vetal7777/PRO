let arr = [11111, 0, false];

alert( arr.includes(11111) ); // true
alert( arr.includes('Ukraine') );//false