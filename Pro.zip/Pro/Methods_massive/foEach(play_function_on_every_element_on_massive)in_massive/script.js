// Его синтаксис:
//     arr.forEach(function(item, index, array) {
//         // ... делать что-то с item
//     });



// Например, этот код выведет на экран каждый элемент массива:

// Вызов alert для каждого элемента
    ["Bilbo", "Gandalf", "Nazgul"].forEach(alert);


// А этот вдобавок расскажет и о своей позиции в массиве:

    ["Bilbo", "Gandalf", "Nazgul"].forEach((item, index, array) => {
        alert(`${item} имеет позицию ${index} в ${array}`);
    });


// Вот пример с константой
const arr = [22,33,34,55];

arr.forEach(function (element, index,array){
    alert(`element ${element}, index ${index}`);
})