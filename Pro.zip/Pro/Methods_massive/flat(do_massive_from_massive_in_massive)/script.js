const test = [[2],[3],[4],[5],[6]];
const result = test.flat();

console.log(result); // [2,3,4,5,6]