const ELEMENT = (tag, id, className, value) =>
    `<${tag} id="${id}" class="${className}">${value}</${tag}>`;
//Стрелочная функция которая собирает строку
const INPUTS_ID = {
    name: 'name',
    lastName: 'lastName',
    phone: 'phone',
};
//Обьект со всеми id наших input
const ERROR_MSGS = {
    nameEmpty: 'Name cannot be empty',
    nameLength: 'Name should be more then 3 symbols',
    lastNameEmpty: 'Last name cannot be empty',
    lastNameLength: 'Last name should be more then 3 symbols',
    phoneEmpty: 'Phone cannot be empty',
    phoneDigitsAmount: 'Phone number must be at least 12 digits length',
};
//Обьект со всеми возможными ошибками наших inputs
const VALIDATION_FUNC = {
    [INPUTS_ID.name]: validateName,
    [INPUTS_ID.lastName]: validateLastName,
    [INPUTS_ID.phone]: validatePhone,
};
//Обьект со всеми функциями по нашим валидацциям
const VALIDATIONS_IDS = {
    name: 'name-validation',
    lastName: 'lastName-validation',
    phone: 'phone-validation',
};
//Обьект со всеми id контейнеров результата валидации по каждому input

const PHONE_REGEXP = /^((\+?3)?8)?0\d{9}$/;
//Cтрока нашего RegEx
const inputsEl = document.querySelectorAll('.user-inputs');
//Массив всех наших inputs
const validationContainers = document.querySelectorAll('.validation-msgs');
//Массив всех наших контейнеров результата валидации
const buttonEl = document.querySelector('#btn');
//Наша кнопка
const containerEl = document.querySelector('.table-container');
//Контейнер для наших контактов
let isAllDataValid = false;
//Прошли мы валидацию или нет (поумолчанию нет)
let errors = [];
//Массив с нашими ошибками
const contacts = [];
//Массив с

buttonEl.addEventListener('click', onContactCreate);
//При нажатии кнопки вызывается функция onContactCreate
//(  Валадирует, и рендерит наш контакт , и чистит после выполнения все inputs)

function onContactCreate() {
    validateAllInputs(inputsEl);
    //Проверяет все inputs
    crateElement(inputsEl);
    //Собирает нашу строку
    renderElement(contacts[contacts.length - 1], containerEl);
    //Закидывает нашу строку в контейнер с результатом
    clearForm();
    //Чистит форму
}

function validateAllInputs(elementsArray) {
    errors = [];
    //Массив с ошибками чистит
    isAllDataValid = ![...elementsArray].filter((element) => !VALIDATION_FUNC[element.id](element)).length;
    //Переменная которая говорит прошли или не прошли валидацию = НЕ(длина копии массива всех inputs , кроме тех inputs чьих id нету в массиве VALIDATION_FUNC)
    //Если у нас нету ошибок то true
    //Если есть ошибки то false
    renderValidationErrors();
    //Что делает данная функция??????????????????????????????????
}

function validateName(element) {
    let result = true;
    //Result - это чтото вроде галочки прошли мы валидацию или нет
    //Поумолчанию true
    if (!element.value.trim()) {
        //Если input name пустой то выполняются следующие действия
        const error = { id: element.id, error: ERROR_MSGS.nameEmpty };
        //Cоздается обьект error с id элемента и текстом ошибки что он пустой
        errors.push(error);
        //Добавляем данный обьект в массив с ошибками
        result = false;
        //    Нет , мы не прошли валидацию
    }
    if (element.value.length <= 3) {
        //Если у input Name меньше слово чем на три буквы то происходит следующее
        const error = { id: element.id, error: ERROR_MSGS.nameLength };
        //Cоздается обьект error с id элемента и текстом ошибки что он короткий
        errors.push(error);
        //Добавляем данный обьект в массив с ошибками
        result = false;
        //    Нет , мы не прошли валидацию
    }
    return result;
    //    Показываем прошли мы валидацию или нет
}
//Проверка input имени
function validateLastName(element) {
    let result = true;
    //Result - это чтото вроде галочки прошли мы валидацию или нет
    //Поумолчанию true
    if (!element.value.trim()) {
        //Если input name пустой то выполняются следующие действия
        const error = { id: element.id, error: ERROR_MSGS.lastNameEmpty };
        //Cоздается обьект error с id элемента и текстом ошибки что он пустой
        errors.push(error);
        //Добавляем данный обьект в массив с ошибками
        result = false;
    //    Нет , мы не прошли валидацию
    }
    if (element.value.length <= 3) {
        //Если у input Name меньше слово чем на три буквы то происходит следующее
        const error = { id: element.id, error: ERROR_MSGS.lastNameLength };
        //Cоздается обьект error с id элемента и текстом ошибки что он короткий
        errors.push(error);
        //Добавляем данный обьект в массив с ошибками
        result = false;
        //    Нет , мы не прошли валидацию
    }
    return result;
//    Показываем прошли мы валидацию или нет
}
//Проверка input фамилии
function validatePhone(element) {
    let result = true;
    //Result - это чтото вроде галочки прошли мы валидацию или нет
    //Поумолчанию true
    const phone = element.value.replace(/[\s\-\(\)]/g, '');
    //Проверяем на наш фильтр в RegEx
    if (!phone.trim()) {
        //Если input пустой то выполняется следующее
        const error = { id: element.id, error: ERROR_MSGS.phoneEmpty };
        //Cоздается обьект error с id элемента и текстом ошибки что он пустой
        errors.push(error);
        //Добавляем данный обьект в массив с ошибками
        result = false;
        //    Нет , мы не прошли валидацию
    }
    if (!phone.match(PHONE_REGEXP)) {
        const error = { id: element.id, error: ERROR_MSGS.phoneDigitsAmount };
        //Cоздается обьект error с id элемента и текстом ошибки что он прописан не правильно
        errors.push(error);
        //Добавляем данный обьект в массив с ошибками
        result = false;
        //    Нет , мы не прошли валидацию
    }
    return result;
    //    Показываем прошли мы валидацию или нет
}
//Проверка input номера телефона

function crateElement(elementsArray) {
    if (isAllDataValid) {
        //Если у нас нету ошибок то
        removeValidationMessages();
        //Чистим наши контейнеры с результатом валидации
        const contact = [...elementsArray].reduce(
            //Cоздаем переменную contacts которая равна ...
            //Копия нашего массива всех inputs, которая....

            (acc, el) => {
                acc[INPUTS_ID[el.id]] = el.value;
                return acc;
            },
            { id: `list-item_${Math.random()}` }
        );
        contacts.push(contact);
        //добовляем наш элемент в контейнер с нашими контактами
    }
}

function renderElement(element, table) {
    if (isAllDataValid) {
        const container = createListItemContainer(
            'div',
            element.id,
            'table-items-wrapper'
        );
        Object.keys(element).forEach((key) => {
            if (key !== 'id') {
                const elem = ELEMENT(
                    'div',
                    key + element[key] + 2,
                    'table-item',
                    element[key]
                );
                container.insertAdjacentHTML('beforeend',elem);
                // container.innerHTML += elem;
            }
        });
        table.append(container);
    }
}

function createListItemContainer(tag, id, className) {
    const container = document.createElement(tag);
    //Container переменная которая равна новому элементу tag
    container.id = id;
    //id у этого тега равен войстсву id
    container.classList.add(className);
    //добовляем новый класс этому элементу
    return container;
//    Наш элемент готов
}
//Добавляет новому элементу новый id и class

function clearForm() {
    if (isAllDataValid) {
        inputsEl.forEach((e) => (e.value = ''));
    }
//    Всем input обнуляем value
}
//    Всем input обнуляем value

function renderValidationErrors() {
    if (errors.length) {
        //Если в массиве с ошибками есть обьекты с ошибками
        removeValidationMessages();
        //Чистим наши контейнеры с результатом валидации
        errors.forEach((e) => {
            const errorContainer = [...validationContainers].find(
                (v) => v.id === VALIDATIONS_IDS[e.id]
            );
            //????
            errorContainer.innerHTML += ELEMENT('div', '', '', e.error);
            //Cобираем наши строки ,с результатом ошибок
        });
    }
}

function removeValidationMessages() {
    validationContainers.forEach((c) => (c.innerHTML = ''));
    //Чистим наши контейнеры с результатом валидации
}
//Чистим наши контейнеры с результатом валидации