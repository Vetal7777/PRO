const url = `https://api.github.com/users/vetal7777`;

fetch(url);