const users = [
    {
        name: 'Vasya',
        age : 18,
        marks:[1,2,3],
    }
];

const jUsers = JSON.stringify(users);

console.log(JSON.parse(jUsers));