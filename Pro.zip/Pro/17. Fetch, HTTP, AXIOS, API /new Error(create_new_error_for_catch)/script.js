const url = 'https://api.github.com/users/dsadasdhfjdshdkashjgkd';

fetch(url)
    .then(r => {
        if(r.status === 404){
            throw new Error('ERROR 404')
        }
        return r.json();
    })
    .catch(e => alert(e));
