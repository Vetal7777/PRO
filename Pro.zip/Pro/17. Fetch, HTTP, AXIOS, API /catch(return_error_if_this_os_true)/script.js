const url = 'https://api.github.com/users/vetal7777';
const btn = document.getElementById('btn');
const list = document.querySelector('.list');

btn.addEventListener('click',onGetTodo);

function onGetTodo(){
    const todos = fetch(url)
        .then((response) => response.json())
        .then((response) => {
            renderTodo(response)
        }).catch((error) => {
            if(error){
                list.innerHTML = `ERROR `;
            }
        });
    console.log(todos);
}

function renderTodo(todos){
    console.log(todos)
    list.innerHTML = todos.map((todos) => {
        console.log(todos)
        return `<li>${todos.avatar_url}</li>`.join()
    });
}