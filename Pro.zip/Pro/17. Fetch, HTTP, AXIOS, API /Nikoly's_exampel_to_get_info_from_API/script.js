const btnE = document.getElementById('btn');
//Наша кнопка

const url = `https://api.github.com/users/vetal7777`;

btnE.addEventListener('click',getGitInfo);

function getGitInfo(){
    const info = fetch(url).then((response)=> {
        response
            .text()
            .then((text) => console.log(JSON.parse(text)));
    });
}