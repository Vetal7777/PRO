const btnE = document.getElementById('btn');

const url = `https://api.github.com/users/vetal7777`;

btnE.addEventListener('click',getGitInfo);

function getGitInfo(){
    const info = fetch(url)
        .then((responce) => responce.text())
        .then((responce) => console.log(responce));
}