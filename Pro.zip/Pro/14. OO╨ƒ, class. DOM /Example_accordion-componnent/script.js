const el = document.querySelector('.accord-container');
const accordion = new Burger(el);