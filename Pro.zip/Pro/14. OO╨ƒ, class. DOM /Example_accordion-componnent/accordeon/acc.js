class Acc{
    static CLASSES = {
        title: 'item-title',
    //Титул
        body: 'item-body',
    //Боди
        display: 'display'
    //Тот что активный
    };
    //Обьект нужных нам классов
    constructor(el) {
        this.el = el;
        //Элемент аккорд это новый аккорд
        this.el.addEventListener('click',this.onTitleClick);
        this.items = [...el.children];
        //Первые дочки аккорда
        this.setChildrenClass();
    }
    setChildrenClass(){
        //Добавляем классы аккорду
        this.items.forEach((e) => {
            //Каждой дочке говорим
            const [title,body] = e.children;
            //Через деструкторизацию распределяем константы первой и второй ВНУЧКИ
            title.classList.toggle(Acc.CLASSES.title);
            body.classList.toggle(Acc.CLASSES.body);
        //    Добовляем соответсвующие классы
        });
    }
    //Функция
    // - Добавляет классы аккорду
    // - Стилизует класс
    onTitleClick = (event) => {
        const target = event.target;
        //Target - константа на которую мы кликнули
        this.items.forEach((e) => {
            //Каждой дочке говорим
            const [title,body] = e.children;
            //Каждую внучку опять обозвали
            if(title === target){
                //если внучка title , это тот обьект на который мы нажали то
                body.classList.toggle(Acc.CLASSES.display);
                //то второму внуку добавляем класс display
            }else {
                body.classList.remove(Acc.CLASSES.display);
                //Если нет , то удаляеим класс дисплей
            }
        });
    }
}