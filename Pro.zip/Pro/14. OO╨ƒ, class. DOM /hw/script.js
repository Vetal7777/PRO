const el = document.querySelector('.tab-container');
const accordion = new Tab(el);