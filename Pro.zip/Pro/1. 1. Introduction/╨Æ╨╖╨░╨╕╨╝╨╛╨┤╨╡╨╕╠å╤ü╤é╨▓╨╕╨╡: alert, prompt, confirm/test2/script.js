let name = prompt('What is your name?', 'Vitalii');

alert(name);