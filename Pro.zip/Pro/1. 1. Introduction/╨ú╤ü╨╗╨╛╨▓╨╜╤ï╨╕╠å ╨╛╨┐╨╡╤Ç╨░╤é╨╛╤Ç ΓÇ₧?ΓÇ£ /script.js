const age = 27;

function askAdult(age){
    let accessAllowed = null;
    if (age > 18){
        accessAllowed = true;
    }else {
        accessAllowed = false;
    }
    return accessAllowed;
}

//это одно и то же

function askAdultNew(age){
    let accessAllowed = (age > 18) ? true : false;
    return accessAllowed;
}

console.log(askAdult(age));
console.log(askAdultNew(age));