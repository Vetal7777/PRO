let question = prompt('Какое «официальное» название JavaScript?','ECMAScript');

if( question === 'ECMAScript'){
    alert('Верно')
}else {
    alert('Не знаете? ECMAScript!');
}