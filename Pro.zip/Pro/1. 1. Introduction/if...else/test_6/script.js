let age = +prompt('Enter the number', 70);

let result = ( !(age >= 14 && age <= 90)) ? 'Cool' : 'Mistake';

alert(result);
//Напишите условие if для проверки, что значение переменной age НЕ находится в диапазоне 14 и 90 включительно.