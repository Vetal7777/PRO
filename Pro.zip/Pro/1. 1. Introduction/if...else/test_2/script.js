let value = +prompt('Enter number',7);

if ( value > 0){
    alert(1);
}else if( value < 0){
    alert(-1);
}else if( value === 0){
    alert(0);
}