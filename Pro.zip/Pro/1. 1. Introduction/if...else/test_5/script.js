let age = +prompt('Enter the number', 70);

let result = ( age >= 14 && age <= 90) ? 'Cool' : 'Mistake';

alert(result);