let message;

if (login == 'Сотрудник') {
    message = 'Привет';
} else if (login == 'Директор') {
    message = 'Здравствуйте';
} else if (login == '') {
    message = 'Нет логина';
} else {
    message = '';
}

//Перепишите if..else с использованием нескольких операторов '?'.

let message = (login === 'Сотрудник') ? 'Привет' :
    (login === 'Директор') ? 'Здраствуйте' :
    (login === '') ? 'Нет логина' :
    '';