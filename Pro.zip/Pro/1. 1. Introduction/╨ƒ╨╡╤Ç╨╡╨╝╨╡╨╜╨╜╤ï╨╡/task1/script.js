let name = 'Джон',
    admin ;
    admin = name;

alert( admin );