const contactList = new ContactList(document
    .querySelector('.component__contact-list'));